import './Login.css';
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

function LoginForm() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    // Simples validação de login
    if (email === 'user@example.com' && password === 'password') {
      alert('Login bem-sucedido!');
      navigate('/shopping-list');
    } else {
      alert('Credenciais inválidas. Tente novamente.');
    }
  };

  return (
    <div className="login-container">
      <h2 className="login-title">Bem-vindos à loja de compras de Eldória!</h2>
      <form className="login-form" onSubmit={handleSubmit}>
        <h3 className="form-title">LOGIN</h3>

        {/* Campo de email */}
        <label htmlFor="email" className="form-label">
          Email
        </label>
        <input
          type="email"
          id="email"
          className="form-input"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Digite seu email"
          required
        />

        {/* Campo de senha */}
        <label htmlFor="password" className="form-label">
          Senha
        </label>
        <input
          type="password"
          id="password"
          className="form-input"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Digite sua senha"
          required
        />

        {/* Botão de login */}
        <button type="submit" className="login-button">
          ENTRAR
        </button>
      </form>

      {/* Link para "Esqueci minha senha" */}
      <div className="forgot-password">
        <a href="/forgot-password" className="forgot-password-link">
          Esqueci minha senha
        </a>
      </div>
    </div>
  );
}

export default LoginForm;
